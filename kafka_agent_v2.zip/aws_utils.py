import os


def get_client(resource: str):
    import boto3

    return boto3.client(resource, region_name=os.getenv("AWS_REGION"))


def get_param(param_name: str) -> str:
    ssm = get_client("ssm")

    value = ssm.get_parameter(Name=param_name)

    return value["Parameter"]["Value"]
