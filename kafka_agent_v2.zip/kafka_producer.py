import logging
import json

from kafka import KafkaProducer

from headerclass import to_tuple
from cloudevents.kafka import conversion
from cloudevents.http import event
from typing import Dict

import aws_utils

def send_message(cloud_id: str, topic: str, message: str, _headers: Dict, type:str):
    """_summary_
    metodo para publicar un mensaje en kafka.
    :type topic: object
    :param _headers:
    :param message:
    :param topic:
    :param cloud_id:
    :param type
    """
    try:

        _headers.update({"id": cloud_id, "datacontenttype": "application/json", "type": type, "source": "source"})

        producer = KafkaProducer(
            ssl_check_hostname=False,
            security_protocol="SSL",
            bootstrap_servers=aws_utils.get_param("/config/all/common/kafka/boostrap-servers-tls").split(","),
            acks=1,
            request_timeout_ms=30000,
            retries=5,
            metadata_max_age_ms=999999999,
            linger_ms=5000)

        ce_event = event.CloudEvent.create(attributes=_headers, data=json.dumps(message))

        from_convertion = conversion.to_binary(event=ce_event, data_marshaller=str)

        header_list = to_tuple(from_convertion.headers)

        producer.send(topic, value=from_convertion.value, headers=header_list)
        producer.flush()
        
       
        return 200
    except Exception as e:
        logging.error(f"Error al enviar el mensaje: {e}")
        return 400

